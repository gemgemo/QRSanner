
import Foundation


struct Constants
{
    internal static let CaptureView = "com.capture.view.io"
}























